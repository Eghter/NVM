package com.nvm;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Solution {

	// Complete the minimumMoves function below.
	private static final Scanner scanner = new Scanner(System.in);
	private static final String FILENAME = "C:\\test\\fileName.txt";
	static int minimumMoves(int[] a, int[] m) {
		int moves = 0;
		for (int i = 0; i < a.length; i++) {
			String[] arr1 = String.valueOf(a[i]).split("");
			String[] arr2 = String.valueOf(m[i]).split("");
			for (int j = 0; j < arr1.length; j++) {
				if(arr1[j]. trim().length() ==0) {
				continue;
			}
			
				int left = Integer.valueOf(arr1[j]);
				int right = Integer.valueOf(arr2[j]);
				moves += Math.abs(left - right);
		   }
		 
	   }
		return moves;
	}	


	public static void main(String[] args) throws IOException{
		try {
			
		BufferedWriter bufferedWriter  = new BufferedWriter(new FileWriter(FILENAME));
		
			
		int aCount = scanner.nextInt();
		scanner.skip("(\r\n|[\n\r\u2028\u2009\u0085])?");
		
		int[] a = new int[aCount];
		
		for (int i = 0; i < aCount; i++) {
			int aItem = scanner.nextInt();
			scanner.skip("(\r\n|[\n\r\u2028\u2009\u0085])?");
			a[i] = aItem;
			
		}
		
		int mCount = scanner.nextInt();
		scanner.skip("(\r\n|[\n\r\u2028\u2009\u0085])?");
		
		int[] m = new int[mCount];
		
		for (int i = 0; i < mCount; i++) {
			int mItem = scanner.nextInt();
			scanner.skip("(\r\n|[\n\r\u2028\u2009\u0085])?");
			m[i] = mItem;
			
		}
			
		int res = minimumMoves(a, m);
		
		bufferedWriter.write(String.valueOf(res));
		bufferedWriter.newLine();
		bufferedWriter.close();
		scanner.close();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
			}
	
	}

	
	
	
	
	
	